<?php
$lLabNumber = 58;
$lTitle = "Lab 58: JSON Web Token (JWT) Security - Cracking Signature Password";
$lQuestion = "Using the Current User Information page, what is the HS256 signature password?";
$lChoice_1 = "trouble";
$lChoice_2 = "snowman";
$lChoice_3 = "rocky";
$lChoice_4 = "stopwatch";
$lChoice_5 = "tabletop";
$lCorrectAnswer = 2;

require_once("labs/lab-template.inc");
?>
