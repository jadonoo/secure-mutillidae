<?php
$lLabNumber = 48;
$lTitle = "Lab 48: Logging - Log Poisoning";
$lQuestion = "In the lab, what type of attack is used to poison the log?";
$lChoice_1 = "SQL injection";
$lChoice_2 = "LDAP injection";
$lChoice_3 = "Cross-site scripting";
$lChoice_4 = "Phishing";
$lChoice_5 = "Sniffing";
$lCorrectAnswer = 3;

require_once("labs/lab-template.inc");
?>