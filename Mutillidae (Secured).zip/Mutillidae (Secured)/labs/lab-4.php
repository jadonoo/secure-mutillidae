<?php
    $lLabNumber = 4;
    $lTitle = "Lab 4: How the Web Really Works - Using Burp-Suite Proxy History";
    $lQuestion = "Use Burp-Suite Proxy History to determine the version of HTTP used by Mutillidae";
    $lChoice_1 = "HTTP/0.9";
    $lChoice_2 = "HTTP/1.0";
    $lChoice_3 = "HTTP/1.1";
    $lChoice_4 = "HTTP/2.0";
    $lChoice_5 = "None of the above";
    $lCorrectAnswer = 3;

    require_once("labs/lab-template.inc");
?>