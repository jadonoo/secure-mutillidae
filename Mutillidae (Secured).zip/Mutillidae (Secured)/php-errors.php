<div class="page-title">Usage Instructions</div>

<?php include_once __SITE_ROOT__.'/includes/back-button.inc';?>

<span>
	Important note: If you use XAMPP Lite or various version of XAMPP on various operating systems, the path for your
	php.ini file may vary. You may even have multiple php.ini files in which case try to modify the one in the Apache
	directory first, then the one in the PHP file if that doesnt do the trick.
	<br/><br/>
	Windows possible default location C:\xampp\php\php.ini, C:\XamppLite\PHP\php.ini, others
	Linux possible default locations: /XamppLite/PHP/php.ini, /XamppLite/apache/bin/php.ini, others
</span>
