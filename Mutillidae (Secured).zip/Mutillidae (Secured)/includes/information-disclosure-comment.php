<?php
/* ------------------------------------------
 * HTML\JAVASCRIPT COMMENTS
* ------------------------------------------ */
/* In general, HTML and JavaScript comments are to
 * be avoided. Commenting is an excellent practice,
* but the comments should be kept on the server
* where they belong. To accomplish this, simply
* use the frameworks comment tags rather than
* the HTML and JavaScript style comments.
*/
switch ($_SESSION["security-level"]){
	  
   		case "2":
   		case "3":
		case "4":
		case "5": // This code is fairly secure
		/*
		* Note: Notice these are PHP comments rather than client side comments.
		* I think the database password is set to blank or perhaps samurai.
		*/
		break;
}// end switch
?>