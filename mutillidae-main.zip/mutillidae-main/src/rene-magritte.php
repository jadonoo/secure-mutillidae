<!DOCTYPE html>
<html lang="en" xml:lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<title>Rene Magritte Frame</title>
	</head>
	<body onload="objHoverDiv = document.getElementById('id-hover-div');">
		<img style="text-align: center;" alt="Rene Magritte Frame" width="464px" height="582px" src="./images/rene-magritte-frame.jpg" />
	</body>
</html>