    <?php
    $lLabNumber = 8;
    $lTitle = "Lab 8: SQL Injection - Extracting data with SQL injection";
    $lQuestion = "Using the User Info page, what is Kevin's password?";
    $lChoice_1 = "password";
    $lChoice_2 = "rover";
    $lChoice_3 = "Password1";
    $lChoice_4 = "YouWillNeverGetMeHacker";
    $lChoice_5 = "42";
    $lCorrectAnswer = 5;

    require_once("labs/lab-template.inc");
?>