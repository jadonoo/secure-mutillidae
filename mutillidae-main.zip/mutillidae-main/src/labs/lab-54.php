<?php
$lLabNumber = 54;
$lTitle = "Lab 54: CORS - Scanning with SSLScan";
$lQuestion = "Which version of SSL does the Mutillidae web server implement?";
$lChoice_1 = "SSL version 0.5";
$lChoice_2 = "SSL version 1";
$lChoice_3 = "SSL version 2";
$lChoice_4 = "SSL version 3";
$lChoice_5 = "The web server does not implement any version of SSL; only TLS";
$lCorrectAnswer = 5;

require_once("labs/lab-template.inc");
?>
