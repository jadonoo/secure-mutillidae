<?php
    $lLabNumber = 34;
    $lTitle = "Lab 34: Session Management - Exfiltrating Data with XSS";
    $lQuestion = "Referring to lab Exfiltrating Data with XSS, what adjustments are required if the IP address of the attacking machine changes?";
    $lChoice_1 = "This change patches the vulnerability";
    $lChoice_2 = "An alert box will pop up within the browser window";
    $lChoice_3 = "The attack will be detected by the defense team";
    $lChoice_4 = "The attacker must copy the new IP address into the cross-site script before sending to the victim";
    $lChoice_5 = "No adjustments are required";
    $lCorrectAnswer = 4;

    require_once("labs/lab-template.inc");
?>





