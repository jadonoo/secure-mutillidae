<?php
$lLabNumber = 41;
$lTitle = "Lab 41: Password Management - Hydra";
$lQuestion = "What is simba's password?";
$lChoice_1 = "password";
$lChoice_2 = "Password1";
$lChoice_3 = "simba";
$lChoice_4 = "trustno1";
$lChoice_5 = "12345678";
$lCorrectAnswer = 1;

require_once("labs/lab-template.inc");
?>