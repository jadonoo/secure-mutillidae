<?php
$lLabNumber = 55;
$lTitle = "Lab 55: Content Security Policy - Testing Content Security Policy (CSP)";
$lQuestion = "Using the Content Security Policy page in Mutillidae, CSP was effective against this attack";
$lChoice_1 = "Cross-site Scripting";
$lChoice_2 = "HTML injection";
$lChoice_3 = "Command injection";
$lChoice_4 = "All of these";
$lChoice_5 = "None of these";
$lCorrectAnswer = 1;

require_once("labs/lab-template.inc");
?>
